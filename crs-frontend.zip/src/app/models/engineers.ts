export class Engineers {
  engineerEmail: string;
  engineerPassword: string;
  engineerName: string;
}
